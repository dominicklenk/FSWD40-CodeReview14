<?php

/* bigevent/index.html.twig */
class __TwigTemplate_9a1bd3be65c577c507e3100a3b21b0c786619a46a7871bea2b70c785d73a592f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "bigevent/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevent/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevent/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
 <h1 class=\"page-header text-center\"> Upcoming events </h1>


   <div class=\"container\">
    <div class=\"row\">
        ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["bigevents"] ?? $this->getContext($context, "bigevents")));
        foreach ($context['_seq'] as $context["_key"] => $context["bigevent"]) {
            // line 10
            echo "        <div class=\"col-md-4 text-center\" style=\"margin-bottom: 30px\" id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "id", array()), "html", null, true);
            echo "\">
            <div style=\"background: MintCream; width:90%; border: solid 1px #ccc\">
                <div style=\"height: 210px;\">
                    <img src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "image", array()), "html", null, true);
            echo "\" class=\"img-responsive\" style=\"max-width: 330px; width:100%; max-heigt: auto\">
                </div>
                <div style=\"background: MintCream;\">
                    <h3>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "name", array()), "html", null, true);
            echo "</h3>
                    <p style=\"background: MintCream\">";
            // line 17
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["bigevent"], "startdate", array()), "d.m.Y, g:i a"), "html", null, true);
            echo "</p>
                    <hr>
                    <p>
                    <a href=\"/bigevent/details/";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-success\">View</a>
                    <a href=\"/bigevent/edit/";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-default\">Edit</a>
                    <a href=\"/bigevent/delete/";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["bigevent"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a> 
                    </p>
                </div>
            </div>    
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bigevent'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "        
    </div>
</div>

    </tbody>

    </table>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bigevent/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 28,  92 => 22,  88 => 21,  84 => 20,  78 => 17,  74 => 16,  68 => 13,  61 => 10,  57 => 9,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}

 <h1 class=\"page-header text-center\"> Upcoming events </h1>


   <div class=\"container\">
    <div class=\"row\">
        {% for bigevent in bigevents %}
        <div class=\"col-md-4 text-center\" style=\"margin-bottom: 30px\" id=\"{{bigevent.id}}\">
            <div style=\"background: MintCream; width:90%; border: solid 1px #ccc\">
                <div style=\"height: 210px;\">
                    <img src=\"{{bigevent.image}}\" class=\"img-responsive\" style=\"max-width: 330px; width:100%; max-heigt: auto\">
                </div>
                <div style=\"background: MintCream;\">
                    <h3>{{bigevent.name}}</h3>
                    <p style=\"background: MintCream\">{{bigevent.startdate|date('d.m.Y, g:i a')}}</p>
                    <hr>
                    <p>
                    <a href=\"/bigevent/details/{{bigevent.id}}\" class=\"btn btn-success\">View</a>
                    <a href=\"/bigevent/edit/{{bigevent.id}}\" class=\"btn btn-default\">Edit</a>
                    <a href=\"/bigevent/delete/{{bigevent.id}}\" class=\"btn btn-danger\">Delete</a> 
                    </p>
                </div>
            </div>    
        </div>
        {% endfor %}
        
    </div>
</div>

    </tbody>

    </table>

{% endblock %}", "bigevent/index.html.twig", "/Applications/MAMP/htdocs/Dominic_Klenk_FSWD40-CodeReview14/app/Resources/views/bigevent/index.html.twig");
    }
}
