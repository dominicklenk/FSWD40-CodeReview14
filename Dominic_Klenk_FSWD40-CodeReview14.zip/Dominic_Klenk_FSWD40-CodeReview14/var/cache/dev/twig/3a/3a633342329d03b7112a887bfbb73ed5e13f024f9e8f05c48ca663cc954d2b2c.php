<?php

/* bigevent/details.html.twig */
class __TwigTemplate_86c72a43aaefea70f463e772b95cf80e39ec21c40110c7df261c9692f93fc717 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "bigevent/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevent/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevent/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

        <h2 class=\"page-header\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "name", array()), "html", null, true);
        echo "</h2>

        <p>
          <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "image", array()), "html", null, true);
        echo "\" class=\"img-responsive\" style=\"height: 150px; float: right\"> ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "description", array()), "html", null, true);
        echo "
        </p>

        <table class=\"table table-striped\" style=\"max-width: 600px; margin-top: 30px \">
          <tr>
            <td width=\"10%\">Start:</td>
            <td width=\"90%\"><strong> ";
        // line 15
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "startdate", array()), "d.m.Y, g:i a"), "html", null, true);
        echo "</strong></td>
          </tr>
          <tr>
            <td>End:</td>
            <td><strong> ";
        // line 19
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "enddate", array()), "d.m.Y, g:i a"), "html", null, true);
        echo "</strong></td>
          </tr>
          <tr>
            <td>Address:</td>
            <td><strong> ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "address", array()), "html", null, true);
        echo "</strong></td>
          </tr>
          <tr>
            <td>Phone:</td>
            <td><strong> ";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "phone", array()), "html", null, true);
        echo "</strong></td>
          </tr>
          <tr>
            <td>Contact:</td>
            <td><strong> <a href=\"mailto:";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "email", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "email", array()), "html", null, true);
        echo "</a></strong></td>
          </tr>
          <tr>
            <td>Homepage:</td>
            <td><strong> <a href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "url", array()), "html", null, true);
        echo "\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "url", array()), "html", null, true);
        echo "</a></strong></td>
          </tr>
          <tr>
            <td>Category:</td>
            <td><strong>";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "type", array()), "html", null, true);
        echo "</strong></td>
          </tr>
            ";
        // line 41
        if ( !twig_test_empty($this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "capacity", array()))) {
            // line 42
            echo "            <td>Capacity:</td>
            <td><strong>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevent"] ?? $this->getContext($context, "bigevent")), "capacity", array()), "html", null, true);
            echo "</strong></td>
            ";
        }
        // line 45
        echo "        </table>

        <hr>
        <a class=\"btn btn-default\" href=\"/\">Back to Events</a>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bigevent/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 45,  126 => 43,  123 => 42,  121 => 41,  116 => 39,  107 => 35,  98 => 31,  91 => 27,  84 => 23,  77 => 19,  70 => 15,  59 => 9,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}


        <h2 class=\"page-header\">{{bigevent.name}}</h2>

        <p>
          <img src=\"{{bigevent.image}}\" class=\"img-responsive\" style=\"height: 150px; float: right\"> {{bigevent.description}}
        </p>

        <table class=\"table table-striped\" style=\"max-width: 600px; margin-top: 30px \">
          <tr>
            <td width=\"10%\">Start:</td>
            <td width=\"90%\"><strong> {{bigevent.startdate|date('d.m.Y, g:i a')}}</strong></td>
          </tr>
          <tr>
            <td>End:</td>
            <td><strong> {{bigevent.enddate|date('d.m.Y, g:i a')}}</strong></td>
          </tr>
          <tr>
            <td>Address:</td>
            <td><strong> {{bigevent.address}}</strong></td>
          </tr>
          <tr>
            <td>Phone:</td>
            <td><strong> {{bigevent.phone}}</strong></td>
          </tr>
          <tr>
            <td>Contact:</td>
            <td><strong> <a href=\"mailto:{{bigevent.email}}\">{{bigevent.email}}</a></strong></td>
          </tr>
          <tr>
            <td>Homepage:</td>
            <td><strong> <a href=\"{{bigevent.url}}\" target=\"_blank\">{{bigevent.url}}</a></strong></td>
          </tr>
          <tr>
            <td>Category:</td>
            <td><strong>{{bigevent.type}}</strong></td>
          </tr>
            {% if bigevent.capacity is not empty %}
            <td>Capacity:</td>
            <td><strong>{{bigevent.capacity}}</strong></td>
            {% endif %}
        </table>

        <hr>
        <a class=\"btn btn-default\" href=\"/\">Back to Events</a>

{% endblock %}", "bigevent/details.html.twig", "/Applications/MAMP/htdocs/Dominic_Klenk_FSWD40-CodeReview14/app/Resources/views/bigevent/details.html.twig");
    }
}
