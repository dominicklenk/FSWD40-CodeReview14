<?php
namespace AppBundle\Controller;

use AppBundle\Entity\BigEvent;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class BigEventsController extends Controller
{
    /**
     * @Route("/", name="bigevent_list")
     */

    public function listAction()
    {
        $bigevents = $this->getDoctrine()->getRepository('AppBundle:BigEvent')->findAll();
        // replace this example code with whatever you need
        return $this->render('bigevent/index.html.twig', array('bigevents'=>$bigevents));
    }

    /**
    * @Route("/bigevent/create", name="bigevent_create")
    */

    public function createAction(Request $request)
    {

        $bigevent = new BigEvent;

        $form = $this->createFormBuilder($bigevent)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('startdate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

        ->add('enddate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))       

        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('type', ChoiceType::class, array('choices'=>array('Dance'=>'Dance', 'Musical'=>'Musical', 'Theater'=>'Theater'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

        

        ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

        ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            //fetching data

            $name = $form['name']->getData();

            $startdate = $form['startdate']->getData();

            $enddate = $form['enddate']->getData();

            $description = $form['description']->getData();

            $image = $form['image']->getData();

            $capacity = $form['capacity']->getData();

            $email = $form['email']->getData();

            $phone = $form['phone']->getData();

            $address = $form['address']->getData();

            $url = $form['url']->getData();

            $type = $form['type']->getData();

            $now = new\DateTime('now');

            $bigevent->setName($name);

            $bigevent->setStartdate($startdate);

            $bigevent->setEnddate($enddate);

            $bigevent->setDescription($description);

            $bigevent->setCapacity($capacity);

            $bigevent->setImage($image);

            $bigevent->setEmail($email);

            $bigevent->setPhone($phone);

            $bigevent->setAddress($address);

            $bigevent->setUrl($url);

            $bigevent->setType($type);

            $em = $this->getDoctrine()->getManager();

            $em->persist($bigevent);

            $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Added'

                    );

            return $this->redirectToRoute('bigevent_list');
        }
        // replace this example code with whatever you need

        return $this->render('bigevent/create.html.twig', array('form' => $form->createView()));

    }

    /**
    * @Route("/bigevent/details/{id}", name="bigevent_details")
    */

    public function detailsAction($id){
    $bigevent = $this->getDoctrine()->getRepository('AppBundle:BigEvent')->find($id);
        return $this->render('bigevent/details.html.twig', array('bigevent' => $bigevent));
    }

    /**
    * @Route("/bigevent/edit/{id}", name="bigevent_edit")
    */

    public function editAction( $id, Request $request){
    $bigevent = $this->getDoctrine()->getRepository('AppBundle:BigEvent')->find($id);
    $now = new\DateTime('now');
    $bigevent->setName($bigevent->getName());
    $bigevent->setStartdate($bigevent->getStartdate());
    $bigevent->setEnddate($bigevent->getEnddate());
    $bigevent->setDescription($bigevent->getDescription());
    $bigevent->setCapacity($bigevent->getCapacity());
    $bigevent->setImage($bigevent->getImage());
    $bigevent->setEmail($bigevent->getEmail());
    $bigevent->setPhone($bigevent->getPhone());
    $bigevent->setAddress($bigevent->getAddress());
    $bigevent->setUrl($bigevent->getUrl());
    $bigevent->setType($bigevent->getType());


    $form = $this->createFormBuilder($bigevent)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

        ->add('startdate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

        ->add('enddate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))       

        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('type', ChoiceType::class, array('choices'=>array('Dance'=>'Dance', 'Musical'=>'Musical', 'Theater'=>'Theater'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))

    ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))

        ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $name = $form['name']->getData();

            $startdate = $form['startdate']->getData();

            $enddate = $form['enddate']->getData();

            $description = $form['description']->getData();

            $image = $form['image']->getData();

            $capacity = $form['capacity']->getData();

            $email = $form['email']->getData();

            $phone = $form['phone']->getData();

            $address = $form['address']->getData();

            $url = $form['url']->getData();

            $type = $form['type']->getData();

            $now = new\DateTime('now');


            $em = $this->getDoctrine()->getManager();

            $bigevent = $em->getRepository('AppBundle:BigEvent')->find($id);

            $bigevent->setName($name);

            $bigevent->setStartdate($startdate);

            $bigevent->setEnddate($enddate);

            $bigevent->setDescription($description);

            $bigevent->setCapacity($capacity);

            $bigevent->setImage($image);

            $bigevent->setEmail($email);

            $bigevent->setPhone($phone);

            $bigevent->setAddress($address);

            $bigevent->setUrl($url);

            $bigevent->setType($type);

            
        

            $em->flush();
            $this->addFlash(
                    'notice',
                    'Event Updated'
                    );

            return $this->redirectToRoute('bigevent_list');
        }
        
        return $this->render('bigevent/edit.html.twig', array('bigevent' => $bigevent, 'form' => $form->createView()));

    }

    /**
     * @Route("/bigevent/delete/{id}", name="bigevent_delete")
     */

    public function deleteAction($id){
            $em = $this->getDoctrine()->getManager();
            $bigevent = $em->getRepository('AppBundle:BigEvent')->find($id);
            $em->remove($bigevent);
            $em->flush();
            $this->addFlash(
                    'notice',
                    'Event Removed'
                    );
             return $this->redirectToRoute('bigevent_list');
    }
    

}